package com.test.so.service;


import com.test.so.domain.PhoneSettings;

/**
 * Created by azizunsal on 24/02/15.
 */
public interface PhoneSettingsService {
    PhoneSettings findById(Long id);
}

### A SpringBoot Application with BoneCP

Demonstrates how to set up a connection pool with BoneCP in a SpringBoot application. 

### To run the application
`mvn clean package && java -jar target/springbootbonecpds.jar`

package com.hse.vooop;

/**
 *
 */
public class Account {

    private Integer amountOfMoney;
    private String type;
    private Long id;
    private String login;
    private String password;

    public static String[] types = {"checking", "saving"};


    /**
     * @param amountOfMoney initial amount of money on the account
     * @param type type of account
     * @param login login of user
     * @param password password of user
     */
    Account(Integer amountOfMoney, String type, String login, String password) {
       this.amountOfMoney = amountOfMoney;
        this.type = type;
        this.login = login;
        this.password = password;
    }

    public Integer getAmountOfMoney() {
        return amountOfMoney;
    }

    public String getType() {
        return type;
    }

    public Long getId() {
        return id;
    }

    public String getLogin() {
        return login;
    }

    public String getPassword() {
        return password;
    }
}

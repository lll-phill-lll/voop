package com.hse.vooop;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.nio.charset.Charset;
import java.util.Random;
import java.util.UUID;


@EnableAutoConfiguration
@EntityScan
@ComponentScan
@SpringBootApplication
@EnableJpaRepositories
class Application implements CommandLineRunner {

    @Autowired
    BankServer server;

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        Checker checker = new Checker(server);
        Bank bank = new Bank(checker, server);

        User user1 = new User(generateRandomStringLong(), generateRandomStringLong(), bank);
        user1.addAccount();
        System.out.println(user1);

        User user2 = new User(generateRandomStringLong(), generateRandomStringLong(), bank);
        user2.addAccount();
        System.out.println(user2);

        user2.bank.CheckBalance(1L, "hello", "world");

        user2.bank.CheckBalance(1L, user1.getLogin(), user1.getPassword());

        boolean res = user1.bank.Transaction(2L, 1L, user2.getLogin(), user2.getPassword(), 500);
        if (res) {
            System.out.println("Transaction succeeded");
        } else {
            System.out.println("Transaction failed");
        }

        Integer money = user2.bank.ChangeBalance(2L, -130, user2.getLogin(), user2.getPassword());
        System.out.println(money);
    }

    private String generateRandomString(Integer length) {
        byte[] array = new byte[length];
        new Random().nextBytes(array);
        return new String(array, Charset.forName("UTF-8"));
    }

    private String generateRandomStringLong() {
        return UUID.randomUUID().toString();
    }
}

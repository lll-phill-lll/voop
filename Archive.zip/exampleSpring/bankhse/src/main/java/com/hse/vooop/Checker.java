package com.hse.vooop;

import com.hse.vooop.database.model.AccountData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Checker {
    private BankServer server;

    @Autowired
    public Checker() {
    }

    /**
     * @param server
     */
    public Checker(BankServer server) {
        this.server = server;
    }


    public boolean CheckPermissions(Long accountId, String login, String password) {
        AccountData account = server.accountDataService.getAccountData(accountId);
        if (account == null) {
            return false;
        }
        return account.getLogin().equals(login) && account.getPassword().equals(password);
    }

    /**
     * @param login
     * @param password
     * @param accountId
     * @param money
     * @return
     */
    public boolean CheckMoney(String login, String password, Long accountId, Integer money) {
        AccountData account = server.accountDataService.getAccountData(accountId);
        if (account == null) {
            return false;
        }
        return account.getAmountOfMoney() >= money;
    }

}

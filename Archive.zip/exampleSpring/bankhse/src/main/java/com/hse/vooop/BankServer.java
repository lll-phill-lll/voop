package com.hse.vooop;

import com.hse.vooop.database.model.AccountData;
import com.hse.vooop.database.services.QueryService;
import com.hse.vooop.database.services.impl.AccountDataServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BankServer {

    @Autowired
    QueryService queryService;
    @Autowired
    AccountDataServiceImpl accountDataService;

    @Autowired
    public BankServer() {
    }

    public Long AddNewAccount(Account account) {
        AccountData accountData = new AccountData(account.getAmountOfMoney(), account.getType(), account.getLogin(), account.getPassword());
        AccountData savedAccountData = accountDataService.addData(accountData);
        return savedAccountData.getId();
    }

    public Integer ChangeBalance(Long accountId, Integer amount) {
        return queryService.changeMoneyAmount(accountId, amount);
    }

    public void ProcessTransaction(Integer money, Integer AccountIdFrom, Integer AccountIdTo) {
        // TODO implement here
    }

    public Integer GetBalance(Integer AccountID) {
        // TODO implement here
        return null;
    }

    public void GetFullAccountInfo(Integer accountId) {
        // TODO implement here
    }

}

package com.hse.vooop;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Random;

@Component
public class User {
    private HashSet<Long> accounts;
    private String login;
    private String password;
    public Bank bank;

    /**
     * @param login
     * @param password
     * @param bank
     */
    User(String login, String password, Bank bank) {
        this.login = login;
        this.password = password;
        this.bank = bank;
        this.accounts = new HashSet<Long>();
    }

    @Autowired
    public User() {
    }

    void addAccount() {
        Random random = new Random();
        accounts.add(this.bank.CreateNewAccount(Account.types[random.nextInt(Account.types.length)], login, password));
    }


    @Override
    public String toString() {
        return "User{" +
                "accounts=" + accounts +
                ", login='" + login + '\'' +
                ", password='" + password + '\'' +
                ", bank=" + bank +
                '}';
    }

    public String getLogin() {
        return login;
    }

    public String getPassword() {
        return password;
    }

    public HashSet<Long> getAccounts() {
        return accounts;
    }
}

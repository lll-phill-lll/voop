package com.hse.vooop;

import com.hse.vooop.database.model.AccountData;

public class Bank {
    private Checker checker;
    private BankServer server;

    public Bank(Checker checker, BankServer server) {
        this.server = server;
        this.checker = checker;
    }

    /**
     * @param type type of account
     * @param login user login
     * @param password user password
     * @return account id
     */
    public Long CreateNewAccount(String type, String login, String password) {
       return server.AddNewAccount(new Account(1000, type, login, password));
    }

    /**
     * @param accountId id of account where we want to check money amount
     * @param login user login
     * @param password user password
     * @return money on given account
     */
    public Integer CheckBalance(Long accountId, String login, String password) {
        boolean accepted = checker.CheckPermissions(accountId, login, password);
        if (accepted) {
            System.out.println("Access granted, account: " + accountId);
            AccountData account = server.accountDataService.getAccountData(accountId);
            if (account  == null) {
                System.out.println("No such account. Id " + accountId);
                return -1;
            }
            return account.getAmountOfMoney();
        }
        System.out.println("Permission denied, account: " + accountId);
        return -1;
    }

    /**
     * @param accountId id of account user wants to change balance
     * @param amount amount of money user wants to change (may be negative))
     * @param login user login
     * @param password user password
     * @return new balance
     */
    public Integer ChangeBalance(Long accountId, Integer amount, String login, String password) {
        boolean access = checker.CheckPermissions(accountId, login, password);
        if (!access) {
            System.out.println("Access denied to change balance of " + accountId);
            return -1;
        }

        if (amount < 0) {
            boolean hasMoney = checker.CheckMoney(login, password, accountId, amount);
            if (!hasMoney) {
                System.out.println("Not enough money on account " + accountId);
                return -1;
            }
        }
        return server.ChangeBalance(accountId, amount);
    }

    /**
     * @param accountIdFrom
     * @param accountIdTo
     * @param fromLogin
     * @param fromPassword
     * @return
     */
    public boolean Transaction(Long accountIdFrom, Long accountIdTo, String fromLogin, String fromPassword, Integer amount) {
        if (accountIdFrom.equals(accountIdTo)) {
           System.out.println("Error, accounts should be different");
           return false;
        }
        boolean access = checker.CheckPermissions(accountIdFrom, fromLogin, fromPassword);
        if (!access) {
            System.out.println("Access denied. Transaction from " + accountIdFrom + " to " + accountIdTo);
            return false;
        }
        boolean haveMoney = checker.CheckMoney(fromLogin, fromPassword, accountIdFrom, amount);
        if (!haveMoney) {
            System.out.println("Not enough money. Transaction from " + accountIdFrom + " to " + accountIdTo);
            return false;
        }

        server.queryService.processTransaction(accountIdFrom, accountIdTo, amount);
        return true;
    }

}

package com.hse.vooop.database.services.impl;

import com.hse.vooop.database.model.AccountData;
import com.hse.vooop.database.repository.AccountDataRepository;
import com.hse.vooop.database.services.AccountDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
public class AccountDataServiceImpl implements AccountDataService<AccountData> {

    @Autowired
    private AccountDataRepository accountDataRepository;

    @Override
    public AccountData addData(AccountData AccountData) {
        return accountDataRepository.saveAndFlush(AccountData);
    }

    @Override
    public void delete(AccountData accountData) {
        accountDataRepository.delete(accountData);
    }

    @Override
    public List<AccountData> getAll() {
        return accountDataRepository.findAll();
    }

    @Override
    public AccountData getAccountData(Long id) {
        Optional<AccountData> account = accountDataRepository.findById(id);
        boolean hasValue = account.isPresent();
        if (!hasValue) {
            return null;
        }
        System.out.println(account.get());
        return account.get();
    }
}

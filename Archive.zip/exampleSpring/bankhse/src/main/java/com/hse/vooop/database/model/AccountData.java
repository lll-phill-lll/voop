package com.hse.vooop.database.model;

import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.*;

@Entity
@Table(name="ACCOUNTDATA")
public class AccountData {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    private Long id;


    @Column(name="AMOUNTOFMONEY")
    private Integer amountOfMoney;
    @Column(name="TYPE")
    private String type;
    @Column(name="LOGIN")
    private String login;
    @Column(name="PASSWORD")
    private String password;

    public AccountData(Integer amountOfMoney, String type, String login, String password) {
        this.amountOfMoney = amountOfMoney;
        this.type = type;
        this.login = login;
        this.password = password;
    }

    @Autowired
    public AccountData() {
    }


    public Long getId() {
        return id;
    }

    public Integer getAmountOfMoney() {
        return amountOfMoney;
    }

    public String getType() {
        return type;
    }

    public String getLogin() {
        return login;
    }

    public String getPassword() {
        return password;
    }

    @Override
    public String toString() {
        return "AccountData{" +
                "id=" + id +
                ", amountOfMoney=" + amountOfMoney +
                ", type='" + type + '\'' +
                ", login='" + login + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}

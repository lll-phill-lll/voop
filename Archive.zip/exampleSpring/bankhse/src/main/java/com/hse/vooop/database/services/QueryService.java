package com.hse.vooop.database.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Service
public class QueryService {
    @Autowired
    private NamedParameterJdbcTemplate jdbcTemplate;
    private final String TRANSACTION = "UPDATE accountdata " +
            "SET amountofmoney = CASE id " +
                "WHEN :idFrom THEN amountofmoney - 500 " +
                "WHEN :idTo THEN amountofmoney + 500 " +
                "ELSE amountofmoney " +
                "END " +
            "WHERE id IN (:idFrom, :idTo)";
    private final String CHANGE_MONEY_AMOUNT = "UPDATE accountdata " +
            "SET amountofmoney = amountofmoney + :amount " +
            "WHERE id=:id " +
            "RETURNING *";


    private static Integer mapAmount(ResultSet rs, int rownumber) throws SQLException {
        return rs.getInt("amountofMoney");
    }

    public void processTransaction(Long idFrom, Long idTo, Integer amount) {
        MapSqlParameterSource in = new MapSqlParameterSource();
        in.addValue("idFrom", idFrom);
        in.addValue("idTo", idTo);
        in.addValue("amount", amount);
        jdbcTemplate.update(TRANSACTION, in);
    }


    public Integer changeMoneyAmount(Long id, Integer amount) {
        MapSqlParameterSource in = new MapSqlParameterSource();
        in.addValue("id", id);
        in.addValue("amount", amount);
        List<Integer> res = jdbcTemplate.query(CHANGE_MONEY_AMOUNT, in, QueryService::mapAmount);
        return res.iterator().next();
    }
}

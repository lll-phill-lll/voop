package com.hse.vooop.database.services;

import java.util.List;

public interface AccountDataService<T> {

    T addData(T data);
    void delete(T data);
    List<T> getAll();
    T getAccountData(Long id);
}

package main;

public class PierLoader extends Thread {
    private Tunnel tunnel;
    private Ship.Type shipType;

    public PierLoader(Tunnel tunnel, Ship.Type shipType) {
        this.tunnel = tunnel;
        this.shipType = shipType;
    }

    @Override
    public void run() {

        while (true) {
            System.out.println("PierLoader: Waiting for the ship of type" + this.shipType);
            Ship ship = this.tunnel.get(this.shipType);
            System.out.println("PierLoader: Wanted ship type" + shipType + "got" + ship);
            //берет из тоннеля корабль соответствующего типа
            ship.start();

            while (ship.countCheck()) {
                //загружает на него товар, пока корабль не наполнится
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println("PierLoader: Ship" + ship + "finished");
        }
    }
}


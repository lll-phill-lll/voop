package main;

public class Ship extends Thread {
    private int count;
    private Size size;
    private Type type;
    private int id;
    private final int TIME_TO_LOAD_ONE_BATCH_MS = 1000;
    private final int BATCH_SIZE = 10;

    public Ship(Type type, Size size, int id) {
        this.id = id;
        this.type = type;
        this.size = size;
    }

    /**
     * Загружает товары на корабль
     */
    @Override
    public void run() {
        System.out.printf("Ship: Adding items to ship %s\n", this);

        while(this.count < this.size.getValue()) {
            try {
                Thread.sleep(this.TIME_TO_LOAD_ONE_BATCH_MS);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            this.count += this.BATCH_SIZE;
            System.out.printf("Ship: Added %d items to ship %s\n", this.BATCH_SIZE, this);
        }
    }

    @Override
    public String toString() {
        return "Ship{" +
                "count=" + count +
                ", size=" + size +
                ", type=" + type +
                ", id=" + id +
                '}';
    }

    public enum Type {
        DRESS(1), BANANA(2), MEAL(3);
        private int type;

        Type(int type) {
            this.type = type;
        }
    }

    public enum Size {
        SMALL(10), MIDDLE(50), LARGE(100);

        Size(int value){
            this.value = value;
        }
        private int value;

        public int getValue() {
            return this.value;
        }
    }

    public Type GetType() {
        return this.type;
    }

    public boolean countCheck() {
        return this.count < this.size.getValue();
    }
}

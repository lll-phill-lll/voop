package main;

import sun.audio.AudioData;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;
import sun.audio.ContinuousAudioDataStream;

import java.io.*;

public class Music extends Thread {
    /**
     * Включает музыку моря
     *
     */

    public void run() {
       playMusic();
    }

    public static void playMusic() {
        File path = new File("beach.wav");

        AudioData data;
        try {
            data = new AudioStream((new FileInputStream(path))).getData();
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
        ContinuousAudioDataStream sound = new ContinuousAudioDataStream((data));
        AudioPlayer.player.start(sound);
    }
}

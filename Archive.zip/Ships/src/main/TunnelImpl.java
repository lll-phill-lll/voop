package main;


import java.util.ArrayList;
import java.util.List;

public class TunnelImpl implements Tunnel {
    private List<Ship> ships = new ArrayList<>();
    private final int MAX_SHIPS_IN_TUNNEL = 5;
    private final int TIME_TO_GO_TO_PIER_MS = 1000;

    @Override
    public synchronized boolean add(Ship element) {
        System.out.println("Tunnel: Trying to add ship " + element);

        if (this.ships.size() >= this.MAX_SHIPS_IN_TUNNEL) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return false;
        }

        this.ships.add(element);
        notifyAll();
        System.out.println("Tunnel: Successfully added ship " + element);
        return true;
    }

    @Override
    public synchronized Ship get(Ship.Type shipType) {
        while(true) {
            if (this.ships.size() > 0) {
                notifyAll();
            }
            for (int i = 0; i != this.ships.size(); ++i) {
                Ship ship = this.ships.get(i);
                if (ship.GetType() == shipType) {
                    this.ships.remove(ship);
                    try {
                        Thread.sleep(this.TIME_TO_GO_TO_PIER_MS);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    return ship;
                }
            }
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

package com.company;


public class Main {

    public static double sqr(double arg) {
        int k = 3;
        ++k;
        return k;
    }

    public static void main(String[] args) {
        System.out.println(sqr(5));
    }
}

package com.hse.vooop;

import com.hse.vooop.database.model.parser.InputParser;
import com.hse.vooop.database.services.DataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import sun.net.www.protocol.https.Handler;

import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.Scanner;

@Component
@Service
public class YDiskDownloader {
    final String host = "webdav.yandex.ru/";
    final String schema = "https://";

    private String login;
    private String password;

    @Autowired
    public YDiskDownloader(){}

    public YDiskDownloader(String login, String password) {
        this.login = login;
        this.password = password;
    }

    private String generateAuthString() {
        String creds = String.format("%s:%s", this.login, this.password);
        String credsEncoded = Base64.getEncoder().encodeToString((creds).getBytes());
        return String.format("Basic %s", credsEncoded);
    }

    /**
     * @param filePath should be somepath/somefile.txt for file with url
     *                 https://disk.yandex.ru/client/disk/somepath/somefile.txt
     * @return stream to read file. Consider reading by chunks
     */
    public InputStream getFileStream(String filePath) throws IOException {
        String requestFullUrl = this.schema + Paths.get(this.host, filePath).toString();

        HttpsURLConnection con;
        URL url = new URL(null, requestFullUrl, new Handler());
        con = (HttpsURLConnection) url.openConnection();
        con.setRequestMethod("GET");

        String auth = generateAuthString();
        System.out.println(auth); // TODO: remove this print
        con.setRequestProperty("Authorization", auth);
        int status = con.getResponseCode();

        if (status != 200) {  // TODO: fix status code
            System.out.printf("File %s was not downloaded due to %d status code\n", filePath, status);

            // read error if possible
            if (con.getErrorStream() != null) {
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(con.getErrorStream()));
                String inputLine;
                StringBuffer content = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    content.append(inputLine);
                }
                in.close();
                // print error message
                System.out.println(content.toString());
            }
            String error = String.format("File %s wasn't downloaded due to status code %d\n", filePath, status);
            throw new IOException(error);
        }

        return con.getInputStream();
    }

    /**
     * Downloads file from yandex disk in chunks and saves it to the host
     *
     * @param filePathFrom file path in yandex disk in format somepath/somefile.txt for file with url
     *                     https://disk.yandex.ru/client/disk/somepath/somefile.txt
     * @param filePathTo host file path
     * @throws IOException catch it
     */
    public void saveToHost(String filePathFrom, String filePathTo) throws IOException {
        InputStream inputStream = getFileStream(filePathFrom);

        File file = new File(filePathTo);
        // if file doesn't exists, then create it
        if (!file.exists()) {
            file.createNewFile();
        }

        FileOutputStream fileOutputStream = new FileOutputStream(file);

        final byte[] buffer = new byte[1024];
        int bytesRead;
        while ((bytesRead = inputStream.read(buffer)) > 0) {
            fileOutputStream.write(buffer, 0, bytesRead);
        }
    }

    /**
     * Downloads file from yandex disk in chunks and saves it to string
     *
     * @param filePathFrom file path in yandex disk in format somepath/somefile.txt for file with url
     *                     https://disk.yandex.ru/client/disk/somepath/somefile.txt
     * @throws IOException catch it
     */

    public String saveToString(String filePathFrom) throws IOException {
        InputStream inputStream = getFileStream(filePathFrom);

        final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        final byte[] buffer = new byte[1024];
        int bytesRead;
        while ((bytesRead = inputStream.read(buffer)) > 0) {
            outputStream.write(buffer, 0, bytesRead);
        }
        return outputStream.toString(StandardCharsets.UTF_8.name());
    }

    /**
     * Downloads file from yandex disk in chunks and saves it to the host
     *
     * @param filePathFrom file path in yandex disk in format somepath/somefile.txt for file with url
     *                     https://disk.yandex.ru/client/disk/somepath/somefile.txt
     * @param service      query service that implements query requests to database
     * @param parser       parser that takes string and returns object
     * @throws IOException catch it
     */
    public void saveToDataBase(String filePathFrom, DataService service, InputParser parser) throws IOException, IllegalArgumentException {
        InputStream inputStream = getFileStream(filePathFrom);
        Scanner sc = new Scanner(inputStream);

        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            service.addData(parser.parseFromString(line));
        }
        System.out.printf("File from %s saved to database\n", filePathFrom);
        inputStream.close();
    }
}

package com.hse.vooop.database.model.parser;

public interface InputParser<T> {
    T parseFromString(String object) throws IllegalArgumentException;
}

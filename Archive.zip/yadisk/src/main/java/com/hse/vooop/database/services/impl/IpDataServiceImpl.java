package com.hse.vooop.database.services.impl;

import com.hse.vooop.database.model.IpData;
import com.hse.vooop.database.repository.IpDataRepository;
import com.hse.vooop.database.services.DataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IpDataServiceImpl implements DataService<IpData> {

    @Autowired
    private IpDataRepository ipDataRepository;

    @Override
    public IpData addData(IpData ipData) {
        return ipDataRepository.saveAndFlush(ipData);
    }

    @Override
    public void delete(IpData ipData) {
        ipDataRepository.delete(ipData);
    }

    @Override
    public List<IpData> getAll() {
        return ipDataRepository.findAll();
    }
}


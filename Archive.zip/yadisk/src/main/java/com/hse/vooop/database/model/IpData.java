package com.hse.vooop.database.model;

import javax.persistence.*;

@Entity
@Table(name="IPDATA")
public class IpData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    private Long id;

    @Column(name="REGION")
    private String region;

    @Column(name="IPADDRESS")
    private String ipAddress;

    public IpData(String region, String ipAddress) {
        this.region = region;
        this.ipAddress = ipAddress;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }


    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }


    @Override
    public String toString() {
        return "IpData{" +
                "id=" + id +
                ", region='" + region + '\'' +
                ", ipAddress='" + ipAddress + '\'' +
                '}';
    }
}

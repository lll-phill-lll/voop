package com.hse.vooop.database.model;

import javax.persistence.*;

@Entity
@Table(name="USERDATA")
public class UserData {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="IPADDRESS")
    private String ipAddress;
    @Column(name="USERBROWSER")
    private String userBrowser;
    @Column(name="SEX")
    private String sex;
    @Column(name="AGE")
    private Integer age;

    public UserData(String ipAddress, String userBrowser, String sex, Integer age) {
        this.ipAddress = ipAddress;
        this.userBrowser = userBrowser;
        this.sex = sex;
        this.age = age;
    }

    public String getUserBrowser() {
        return userBrowser;
    }

    public void setUserBrowser(String userBrowser) {
        this.userBrowser = userBrowser;
    }


    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String isSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }
}

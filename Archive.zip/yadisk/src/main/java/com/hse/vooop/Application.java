package com.hse.vooop;

import com.hse.vooop.DTO.Region;
import com.hse.vooop.DTO.User;
import com.hse.vooop.tasks.ConsoleTasks;
import com.hse.vooop.tasks.YDiskTasks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.LinkedList;
import java.util.List;


@EnableAutoConfiguration
@ComponentScan
@EntityScan
@ComponentScan
@SpringBootApplication
@EnableJpaRepositories
class Application implements CommandLineRunner {
    @Autowired
    ConsoleTasks consoleTasks;

    @Autowired
    YDiskTasks yDiskTasks;

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        yDiskTasks.saveAllDataToDB();

        List<Integer> tasks = new LinkedList<>();
        tasks.add(1);
        tasks.add(2);
        tasks.add(3);
        tasks.add(4);
        tasks.add(5);
        tasks.add(6);
        tasks.add(7);
        tasks.add(8);
        consoleTasks.executeNumberOfTasks(tasks);

    }
}

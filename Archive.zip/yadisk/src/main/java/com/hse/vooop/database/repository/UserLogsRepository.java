package com.hse.vooop.database.repository;

import com.hse.vooop.database.model.UserLogs;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserLogsRepository extends JpaRepository<UserLogs, Long> {
}

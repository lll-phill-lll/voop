package com.hse.vooop.database.services.impl;

import com.hse.vooop.database.model.UserData;
import com.hse.vooop.database.repository.UserDataRepository;
import com.hse.vooop.database.services.DataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserDataServiceImpl implements DataService<UserData> {

    @Autowired
    private UserDataRepository userDataRepository;

    @Override
    public UserData addData(UserData userData) {
        return userDataRepository.saveAndFlush(userData);
    }

    @Override
    public void delete(UserData userData) {
        userDataRepository.delete(userData);
    }

    @Override
    public List<UserData> getAll() {
        return userDataRepository.findAll();
    }
}

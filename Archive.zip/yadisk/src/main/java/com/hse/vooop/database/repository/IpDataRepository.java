package com.hse.vooop.database.repository;


import com.hse.vooop.database.model.IpData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IpDataRepository extends JpaRepository<IpData, Long> {
}


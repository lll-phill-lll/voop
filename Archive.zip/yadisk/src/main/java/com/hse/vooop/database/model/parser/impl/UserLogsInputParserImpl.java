package com.hse.vooop.database.model.parser.impl;

import com.hse.vooop.database.model.UserLogs;
import com.hse.vooop.database.model.parser.InputParser;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class UserLogsInputParserImpl implements InputParser<UserLogs> {

    @Override
    public UserLogs parseFromString(String lineObject) throws IllegalArgumentException {
        String[] parsed = lineObject.split("\\s+", 6);
        if (parsed.length != 6) {
            throw new IllegalArgumentException("can't parse " + lineObject);
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("YYYYMMddhhmmss");
        Date parsedDate;
        try {
            parsedDate = dateFormat.parse(parsed[1]);
        } catch (ParseException e) {
            e.printStackTrace();
            String error = String.format("Can't parse %s to timestamp", parsed[1]);
            throw new IllegalArgumentException(error);
        }
        Timestamp timestamp = new Timestamp(parsedDate.getTime());


        int pageSize;
        try {
            pageSize = Integer.parseInt(parsed[3]);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            String error = String.format("Can't convert string %s to int", parsed[3]);
            throw new IllegalArgumentException(error);
        }

        int httpStatus;
        try {
            httpStatus = Integer.parseInt(parsed[4]);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            String error = String.format("Can't convert string %s to int", parsed[4]);
            throw new IllegalArgumentException(error);
        }
        return new UserLogs(parsed[0], timestamp, parsed[2], pageSize, httpStatus, parsed[5]);
    }
}

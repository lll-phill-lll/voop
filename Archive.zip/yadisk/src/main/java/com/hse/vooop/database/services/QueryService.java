package com.hse.vooop.database.services;

import com.hse.vooop.DTO.Region;
import com.hse.vooop.DTO.User;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

@Service
public class QueryService {
    private NamedParameterJdbcTemplate jdbcTemplate;

    private final String TEST = "SELECT ipaddress FROM :tableName WHERE region='Komi'";


    private final String TOP_TEN_ACTIVE_USERS_SINCE_DATE_QUERY = "SELECT * from (select ipaddress, max(userbrowser) as userbrowser, max(sex) as sex, max(age) " +
            "as age from userdata group by ipaddress) userdata inner join (SELECT ipaddress, COUNT(ipaddress) AS count FROM userlogs  WHERE timestamp>(SELECT " +
            "MAX(timestamp) -1 * interval '1000 second' from userlogs) GROUP BY ipaddress ORDER BY count DESC LIMIT 10) as o on o.ipaddress = userdata.ipaddress;";
    private final String REGIONS_WITH_TOTAL_VISITINGS_MORE_THEN_AVG_VISITING_AMONG_REGIONS = "SELECT region FROM (SELECT userlogs.ipaddress, region " +
            "FROM userlogs INNER JOIN (SELECT  ipaddress, MIN(region) AS region FROM ipdata GROUP BY ipaddress) ipdata ON ipdata.ipaddress = userlogs.ipaddress) " +
            "AS a GROUP BY region HAVING COUNT(region) > (SELECT COUNT(region) / COUNT(DISTINCT region) AS avg FROM (SELECT userlogs.ipaddress, region FROM userlogs " +
            "INNER JOIN (SELECT  ipaddress, MIN(region) AS region FROM ipdata GROUP BY ipaddress) ipdata ON ipdata.ipaddress = userlogs.ipaddress) AS a)";
    private final String DELETE_OUTDATED_USER_LOGS = "DELETE FROM userlogs WHERE timestamp > :timestamp";
    private final String REPLACE_RU_DOMENS_IN_USER_LOGS_WITH_COM_SINCE = "UPDATE userlogs SET httprequest = REPLACE(httprequest, '.ru', '.com') WHERE timestamp > :timestamp";
    private final String TOP_TEN_REGIONS_WITH_TOP_VISITS_TO_LENTA_RU_SINCE = "SELECT region AS region FROM userlogs INNER JOIN (SELECT max(region) AS region, ipdata.ipaddress FROM " +
            "ipdata GROUP BY ipaddress) AS new_row ON new_row.ipaddress = userlogs.ipaddress WHERE timestamp > :timestamp GROUP BY region ORDER BY COUNT(*) DESC LIMIT 10";

    public QueryService(DataSource dataSource) {
        this.jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
    }

    private static User mapRowTopTenActiveUsersSinceDate(ResultSet rs, int rownumber) throws SQLException {
        String ip = rs.getString("ipaddress");
        String browser = rs.getString("userbrowser");
        String sex = rs.getString("sex");
        int age = rs.getInt("age");
        int count = rs.getInt("count");
        return new User(ip, browser, sex, age, count);
    }

    private static Region mapRowRegionsWithTotalVisitingsMoreThenAvgVisitingsAmongRegion(ResultSet rs, int rownumber) throws SQLException {
        String reg= rs.getString("region");
        return new Region(reg);
    }

    private static Region mapRowTopTenRegionsWithTopVisitorsToLentaRuSince(ResultSet rs, int rownumber) throws SQLException {
        String reg = rs.getString("region");
        return new Region(reg);
    }

    // changed days to seconds to avoid empty results
    public List<User> topTenActiveUsersSinceDate(int seconds) {
        MapSqlParameterSource in = new MapSqlParameterSource();
        in.addValue(":seconds", seconds);
        String sec = Integer.toString(seconds);
        // made this cheat because of a bug when NamedParameterJdbc fails with single quotes. TODO remove when fixed
        String query = this.TOP_TEN_ACTIVE_USERS_SINCE_DATE_QUERY.replaceAll(":second", sec);
        List<User> l =  jdbcTemplate.query(query, in, QueryService::mapRowTopTenActiveUsersSinceDate);
        return l;
    }

    public List<Region> regionsWithTotalVisitingsMoreThenAvgVisitingsAmongRegion() {
        List<Region> l =  jdbcTemplate.query(this.REGIONS_WITH_TOTAL_VISITINGS_MORE_THEN_AVG_VISITING_AMONG_REGIONS, QueryService::mapRowRegionsWithTotalVisitingsMoreThenAvgVisitingsAmongRegion);
        return l;
    }

    // added top 10
    public List<Region> topTenRegionsWithTopVisitorsToLentaRuSince(Timestamp timestamp) {
        MapSqlParameterSource in = new MapSqlParameterSource();
        in.addValue("timestamp", timestamp);
        List<Region> l =  jdbcTemplate.query(this.TOP_TEN_REGIONS_WITH_TOP_VISITS_TO_LENTA_RU_SINCE, in, QueryService::mapRowTopTenRegionsWithTopVisitorsToLentaRuSince);
        return l;
    }

    public void deleteOutdatedUserLogs(Timestamp timestamp) {
        MapSqlParameterSource in = new MapSqlParameterSource();
        in.addValue("timestamp", timestamp);
        jdbcTemplate.update(DELETE_OUTDATED_USER_LOGS, in);
    }

    public void replaceRuDomensInUserLogsWithComSince(Timestamp timestamp) {
        MapSqlParameterSource in = new MapSqlParameterSource();
        in.addValue("timestamp", timestamp);
        jdbcTemplate.update(REPLACE_RU_DOMENS_IN_USER_LOGS_WITH_COM_SINCE, in);
    }
}

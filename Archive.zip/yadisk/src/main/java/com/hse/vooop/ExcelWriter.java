package com.hse.vooop;

import com.hse.vooop.DTO.Region;
import com.hse.vooop.DTO.User;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.List;

// TODO remove code duplicates

@Component
public class ExcelWriter {
    private HSSFWorkbook workbook;

    @Autowired
    public ExcelWriter() {
        this.workbook = new HSSFWorkbook();
    }

    public void saveMultipleUser(List<User> users, String tableName) throws NoSuchFieldException, IllegalAccessException {
        HSSFSheet sheet = workbook.createSheet(tableName);
        sheet.setColumnWidth(0, 6000);
        sheet.setColumnWidth(1, 4000);

        Row header = sheet.createRow(0);

        CellStyle headerStyle = workbook.createCellStyle();
        headerStyle.setLocked(true);
        headerStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        HSSFFont font = workbook.createFont();
        font.setFontName("Arial");
        font.setFontHeightInPoints((short) 16);
        font.setBold(true);
        headerStyle.setFont(font);

        Cell headerCell;

        Field[] userFields = User.class.getDeclaredFields();
        int i = 0;
        for (Field field : userFields) {
            String name = field.getName();

            headerCell = header.createCell(i);
            headerCell.setCellValue(name);
            headerCell.setCellStyle(headerStyle);
            ++i;
        }

        CellStyle style = workbook.createCellStyle();
        style.setWrapText(true);

        int rowCount = 2;
        for (User user : users) {
            int cellCount = 0;
            Row row = sheet.createRow(rowCount);
            for (Field field : userFields) {
                String fieldName = field.getName();
                Field currentField = user.getClass().getDeclaredField(fieldName);
                currentField.setAccessible(true);
                String value = String.valueOf(currentField.get(user));
                Cell cell = row.createCell(cellCount);
                cell.setCellStyle(style);
                cell.setCellValue(value);
                System.out.println(fieldName + " " + value + " " + cellCount);
                ++cellCount;

            }
            ++rowCount;
        }

    }
    public void saveMultipleRegion(List<Region> regions, String tableName) throws NoSuchFieldException, IllegalAccessException {
        HSSFSheet sheet = workbook.createSheet(tableName);
        sheet.setColumnWidth(0, 6000);
        sheet.setColumnWidth(1, 4000);

        Row header = sheet.createRow(0);

        CellStyle headerStyle = workbook.createCellStyle();
        headerStyle.setLocked(true);
        headerStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        HSSFFont font = workbook.createFont();
        font.setFontName("Arial");
        font.setFontHeightInPoints((short) 16);
        font.setBold(true);
        headerStyle.setFont(font);

        Cell headerCell;

        Field[] userFields = Region.class.getDeclaredFields();
        int i = 0;
        for (Field field : userFields) {
            String name = field.getName();

            headerCell = header.createCell(i);
            headerCell.setCellValue(name);
            headerCell.setCellStyle(headerStyle);
            ++i;
        }

        CellStyle style = workbook.createCellStyle();
        style.setWrapText(true);

        int rowCount = 2;
        for (Region region : regions) {
            int cellCount = 0;
            Row row = sheet.createRow(rowCount);
            for (Field field : userFields) {
                String fieldName = field.getName();
                Field currentField = region.getClass().getDeclaredField(fieldName);
                currentField.setAccessible(true);
                String value = String.valueOf(currentField.get(region));
                Cell cell = row.createCell(cellCount);
                cell.setCellStyle(style);
                cell.setCellValue(value);
                System.out.println(fieldName + " " + value + " " + cellCount);
                ++cellCount;

            }
            ++rowCount;
        }

    }

    public void saveFile() throws IOException {
        File currDir = new File(".");
        String path = currDir.getAbsolutePath();
        String fileLocation = path.substring(0, path.length() - 1) + "multiple.xls";

        FileOutputStream outputStream = new FileOutputStream(fileLocation);
        workbook.write(outputStream);
        workbook.close();

    }

    public static void saveUsers(List<User> users, String tableName) throws IOException, NoSuchFieldException, IllegalAccessException {
        Workbook workbook = new XSSFWorkbook();

        Sheet sheet = workbook.createSheet(User.getTableName());
        sheet.setColumnWidth(0, 6000);
        sheet.setColumnWidth(1, 4000);

        Row header = sheet.createRow(0);

        CellStyle headerStyle = workbook.createCellStyle();
        headerStyle.setLocked(true);
        headerStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        XSSFFont font = ((XSSFWorkbook) workbook).createFont();
        font.setFontName("Arial");
        font.setFontHeightInPoints((short) 16);
        font.setBold(true);
        headerStyle.setFont(font);

        Cell headerCell;

        Field[] userFields = User.class.getDeclaredFields();
        int i = 0;
        for (Field field : userFields) {
            String name = field.getName();

            headerCell = header.createCell(i);
            headerCell.setCellValue(name);
            headerCell.setCellStyle(headerStyle);
            ++i;
        }

        CellStyle style = workbook.createCellStyle();
        style.setWrapText(true);

        int rowCount = 2;
        for (User user : users) {
            int cellCount = 0;
            Row row = sheet.createRow(rowCount);
            for (Field field : userFields) {
                String fieldName = field.getName();
                Field currentField = user.getClass().getDeclaredField(fieldName);
                currentField.setAccessible(true);
                String value = String.valueOf(currentField.get(user));
                Cell cell = row.createCell(cellCount);
                cell.setCellStyle(style);
                cell.setCellValue(value);
                System.out.println(fieldName + " " + value + " " + cellCount);
                ++cellCount;

            }
            ++rowCount;
        }

        File currDir = new File(".");
        String path = currDir.getAbsolutePath();
        String fileLocation = path.substring(0, path.length() - 1) + tableName + ".xlsx";

        FileOutputStream outputStream = new FileOutputStream(fileLocation);
        workbook.write(outputStream);
        workbook.close();
    }

    public static void saveRegions(List<Region> regions, String tableName) throws IOException, NoSuchFieldException, IllegalAccessException {
        Workbook workbook = new XSSFWorkbook();

        Sheet sheet = workbook.createSheet(Region.getTableName());
        sheet.setColumnWidth(0, 6000);
        sheet.setColumnWidth(1, 4000);

        Row header = sheet.createRow(0);

        CellStyle headerStyle = workbook.createCellStyle();
        headerStyle.setLocked(true);
        headerStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        XSSFFont font = ((XSSFWorkbook) workbook).createFont();
        font.setFontName("Arial");
        font.setFontHeightInPoints((short) 16);
        font.setBold(true);
        headerStyle.setFont(font);

        Cell headerCell;

        Field[] userFields = Region.class.getDeclaredFields();
        int i = 0;
        for (Field field : userFields) {
            String name = field.getName();

            headerCell = header.createCell(i);
            headerCell.setCellValue(name);
            headerCell.setCellStyle(headerStyle);
            ++i;
        }

        CellStyle style = workbook.createCellStyle();
        style.setWrapText(true);

        int rowCount = 2;
        for (Region region : regions) {
            int cellCount = 0;
            Row row = sheet.createRow(rowCount);
            for (Field field : userFields) {
                String fieldName = field.getName();
                Field currentField = region.getClass().getDeclaredField(fieldName);
                currentField.setAccessible(true);
                String value = String.valueOf(currentField.get(region));
                Cell cell = row.createCell(cellCount);
                cell.setCellStyle(style);
                cell.setCellValue(value);
                System.out.println(fieldName + " " + value + " " + cellCount);
                ++cellCount;

            }
            ++rowCount;
        }

        File currDir = new File(".");
        String path = currDir.getAbsolutePath();
        String fileLocation = path.substring(0, path.length() - 1) + Region.getTableName() + tableName + ".xlsx";

        FileOutputStream outputStream = new FileOutputStream(fileLocation);
        workbook.write(outputStream);
        workbook.close();
    }
}

package com.hse.vooop.database.model.parser.impl;

import com.hse.vooop.database.model.IpData;
import com.hse.vooop.database.model.parser.InputParser;
import org.springframework.stereotype.Component;

@Component
public class IpDataInputParserImpl implements InputParser<IpData> {

    @Override
    public IpData parseFromString(String lineObject) throws IllegalArgumentException {
        String[] parsed = lineObject.split("\\s+", 2);
        if (parsed.length != 2) {
            throw new IllegalArgumentException("can't parse " + lineObject);
        }
        return new IpData(parsed[1], parsed[0]);
    }
}

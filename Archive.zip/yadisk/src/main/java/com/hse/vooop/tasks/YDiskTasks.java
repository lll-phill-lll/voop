package com.hse.vooop.tasks;

import com.hse.vooop.YDiskDownloader;
import com.hse.vooop.database.model.parser.impl.IpDataInputParserImpl;
import com.hse.vooop.database.model.parser.impl.UserDataInputParserImpl;
import com.hse.vooop.database.model.parser.impl.UserLogsInputParserImpl;
import com.hse.vooop.database.services.impl.IpDataServiceImpl;
import com.hse.vooop.database.services.impl.UserDataServiceImpl;
import com.hse.vooop.database.services.impl.UserLogsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class YDiskTasks {
    private YDiskDownloader downloader;

    @Autowired
    IpDataServiceImpl ipDataService;
    @Autowired
    IpDataInputParserImpl ipDataParser;

    @Autowired
    UserDataServiceImpl userDataService;
    @Autowired
    UserDataInputParserImpl userDataParser;

    @Autowired
    UserLogsServiceImpl userLogsService;
    @Autowired
    UserLogsInputParserImpl userLogsParser;

    public YDiskTasks() {
        this.downloader = new YDiskDownloader("filitovme@yandex.ru", "Phill121");
    }

    public void saveUserLogsToDB() throws IOException {
        this.downloader.saveToDataBase("Загрузки/HSE-OOP-HW4-Data/user_logs_M/logsLM.txt", userLogsService, userLogsParser);
    }
    public void saveIpDataToDB() throws IOException {
        this.downloader.saveToDataBase("Загрузки/HSE-OOP-HW4-Data/ip_data_M/ipDataM.txt", ipDataService, ipDataParser);
    }
    public void saveUserDataToDB() throws IOException {
        this.downloader.saveToDataBase("Загрузки/HSE-OOP-HW4-Data/user_data_M/userDataM", userDataService, userDataParser);
    }

    public void saveAllDataToDB() throws IOException {
        this.saveIpDataToDB();
        this.saveUserDataToDB();
        this.saveUserLogsToDB();
    }

}

package com.hse.vooop.database.model;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name="USERLOGS")
public class UserLogs {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="IPADDRESS")
    private String ipAddress;
    @Column(name="TIMESTAMP")
    private Timestamp timestamp;
    @Column(name="HTTPREQUEST")
    private String httpRequest;
    @Column(name="PAGESIZE")
    private Integer pageSize;
    @Column(name="HTTPSTATUS")
    private Integer httpStatus;
    @Column(name="METADATA")
    private String metadata;

    public UserLogs(String ipAddress, Timestamp timestamp, String httpRequest, Integer pageSize, Integer httpStatus, String metadata) {
        this.ipAddress = ipAddress;
        this.timestamp = timestamp;
        this.httpRequest = httpRequest;
        this.pageSize = pageSize;
        this.httpStatus = httpStatus;
        this.metadata = metadata;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    public String getHttpRequest() {
        return httpRequest;
    }

    public void setHttpRequest(String httpRequest) {
        this.httpRequest = httpRequest;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getHttpStatus() {
        return httpStatus;
    }

    public void setHttpStatus(Integer httpStatus) {
        this.httpStatus = httpStatus;
    }

    public String getMetedata() {
        return metadata;
    }

    public void setMetedata(String metedata) {
        this.metadata = metedata;
    }
}

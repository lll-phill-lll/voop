package com.hse.vooop.tasks;

import com.hse.vooop.DTO.Region;
import com.hse.vooop.DTO.User;
import com.hse.vooop.ExcelWriter;
import com.hse.vooop.database.model.UserLogs;
import com.hse.vooop.database.services.QueryService;
import com.hse.vooop.database.services.impl.UserLogsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Component
public class ConsoleTasks {
    @Autowired
    QueryService queryService;

    @Autowired
    UserLogsServiceImpl userLogsService;

    @Autowired
    ExcelWriter excelWriter;

    // task 1
    public void topTenActiveUsersSinceDate(int seconds, boolean saveToExcelSingle, boolean saveToExcelMultiple, String tableName) throws IllegalAccessException, NoSuchFieldException, IOException {
        List<User> users = queryService.topTenActiveUsersSinceDate(seconds);
        if (saveToExcelSingle) {
            ExcelWriter.saveUsers(users, tableName);
        } else if (saveToExcelMultiple) {
            excelWriter.saveMultipleUser(users, tableName);
        }
    }

    // task 2
    public void regionsWithTotalVilitingsMoreThenAvgVisitingsAmongRegions(boolean saveToExcelSingle, boolean saveToExcelMultiple, String tableName) throws IllegalAccessException, NoSuchFieldException, IOException {
        List<Region> regions = queryService.regionsWithTotalVisitingsMoreThenAvgVisitingsAmongRegion();
        if (saveToExcelSingle) {
            ExcelWriter.saveRegions(regions, tableName);
        } else if (saveToExcelMultiple) {
            excelWriter.saveMultipleRegion(regions, tableName);
        }
    }

    // task 5
    public void topTenRegionsWithTopVisitorsToLentaRuSince(String ts, boolean saveToExcelSingle, boolean saveToExcelMultiple, String tableName) throws ParseException, IllegalAccessException, NoSuchFieldException, IOException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("YYYYMMddhhmmss");
        Date parsedDate;
        parsedDate = dateFormat.parse(ts);
        Timestamp timestamp = new Timestamp(parsedDate.getTime());
        List<Region> regions = queryService.topTenRegionsWithTopVisitorsToLentaRuSince(timestamp);
        if (saveToExcelSingle) {
            ExcelWriter.saveRegions(regions, tableName);
        } else if (saveToExcelMultiple) {
            excelWriter.saveMultipleRegion(regions, tableName);
        }
    }

    // task 6
    public void addNewDataToUSerLogs(UserLogs userlogs) {
        userLogsService.addData(userlogs);
    }

    // task 7
    public void deleteOutdatedUserLogs(String ts) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("YYYYMMddhhmmss");
        Date parsedDate;
        try {
            parsedDate = dateFormat.parse(ts);
        } catch (ParseException e) {
            e.printStackTrace();
            return;
        }
        Timestamp timestamp = new Timestamp(parsedDate.getTime());
        queryService.deleteOutdatedUserLogs(timestamp);
    }

    // task 8
    public void replaceRuDomensInUserLogsWithComSince(String ts) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("YYYYMMddhhmmss");
        Date parsedDate;
        try {
            parsedDate = dateFormat.parse(ts);
        } catch (ParseException e) {
            e.printStackTrace();
            return;
        }
        Timestamp timestamp = new Timestamp(parsedDate.getTime());
        queryService.replaceRuDomensInUserLogsWithComSince(timestamp);
    }

    public void executeNumberOfTasks(List<Integer> tasks) throws IllegalAccessException, NoSuchFieldException, IOException, ParseException {
        for (Integer taskNum : tasks) {
            switch (taskNum) {
                case 1:
                    this.topTenActiveUsersSinceDate(15, false, true, "topTenActiveUsersSinceDate");
                    break;
                case 2:
                    this.regionsWithTotalVilitingsMoreThenAvgVisitingsAmongRegions(false, true,  "regionsWithTotalVilitingsMoreThenAvgVisitingsAmongRegions");
                    break;
                case 5:
                    this.topTenRegionsWithTopVisitorsToLentaRuSince("20140101023103", false, true, "topTenRegionsWithTopVisitorsToLentaRuSince");
                    break;
                case 6:
                    this.addNewDataToUSerLogs(new UserLogs("hello", Timestamp.valueOf("2019-05-19 15:13:54.990"), "world", 3, 4, "hell"));
                    break;
                case 7:
                    this.deleteOutdatedUserLogs("20140101023103");
                    break;
                case 8:
                    this.replaceRuDomensInUserLogsWithComSince("20140101023103");
                    break;
                default:
                    System.out.println("Incorrect number " + taskNum);
            }
        }
        excelWriter.saveFile();
    }

}

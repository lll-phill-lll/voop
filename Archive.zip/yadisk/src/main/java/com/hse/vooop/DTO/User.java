package com.hse.vooop.DTO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class User {
    final static String tableName = "User";

    private String ipAddress;
    private String userBrowser;
    private String sex;
    private Integer age;
    private Integer count;

    @Autowired
    public User(){}

    public User(String ipAddress, String userBrowser, String sex, Integer age, Integer count) {
        this.ipAddress = ipAddress;
        this.userBrowser = userBrowser;
        this.sex = sex;
        this.age = age;
        this.count = count;
    }

    @Override
    public String toString() {
        return "User{" +
                "ipAddress='" + ipAddress + '\'' +
                ", userBrowser='" + userBrowser + '\'' +
                ", sex='" + sex + '\'' +
                ", age=" + age +
                ", count=" + count +
                '}';
    }

    public static String getTableName() {
        return tableName;
    }
}

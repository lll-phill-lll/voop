package com.hse.vooop.DTO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Region {
    final static String tableName = "Region";

    private String name;

    @Autowired
    public Region(){}

    public Region(String name) {
        this.name = name;
    }

    public static String getTableName() {
        return tableName;
    }

    @Override
    public String toString() {
        return "Region{" +
                "name='" + name + '\'' +
                '}';
    }
}

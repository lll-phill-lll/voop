
package com.hse.vooop.database.services.impl;

import com.hse.vooop.database.model.UserLogs;
import com.hse.vooop.database.repository.UserLogsRepository;
import com.hse.vooop.database.services.DataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserLogsServiceImpl implements DataService<UserLogs> {

    @Autowired
    private UserLogsRepository userLogsRepository;

    @Override
    public UserLogs addData(UserLogs userLogs) {
        return userLogsRepository.saveAndFlush(userLogs);
    }

    @Override
    public void delete(UserLogs userLogs) {
        userLogsRepository.delete(userLogs);
    }

    @Override
    public List<UserLogs> getAll() {
        return userLogsRepository.findAll();
    }
}

package com.hse.vooop.database.services;


import java.util.List;

public interface DataService<T> {

    T addData(T data);
    void delete(T data);
    List<T> getAll();
}

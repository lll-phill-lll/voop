package com.hse.vooop.database.model.parser.impl;

import com.hse.vooop.database.model.UserData;
import com.hse.vooop.database.model.parser.InputParser;
import org.springframework.stereotype.Component;

@Component
public class UserDataInputParserImpl implements InputParser<UserData> {

    @Override
    public UserData parseFromString(String lineObject) throws IllegalArgumentException {
        String[] parsed = lineObject.split("\\s+", 4);
        if (parsed.length != 4) {
            throw new IllegalArgumentException("can't parse " + lineObject);
        }
        int age = 0;
        try {
            age = Integer.parseInt(parsed[3]);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            String error = String.format("Can't convert string %s to int", parsed[3]);
            throw new IllegalArgumentException(error);
        }

        return new UserData(parsed[0], parsed[1], parsed[2], age);
    }
}

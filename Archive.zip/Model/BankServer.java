
import java.util.*;

/**
 * 
 */
public class BankServer {

    /**
     * Default constructor
     */
    public BankServer() {
    }

    /**
     * 
     */
    private HashMap Accounts;




    /**
     * @param account 
     * @return
     */
    public Integer AddNewAccount(Account account) {
        // TODO implement here
        return null;
    }

    /**
     * @param AccountId 
     * @param amount 
     * @return
     */
    public Integer ChangeBalance(string AccountId, Integer amount) {
        // TODO implement here
        return null;
    }

    /**
     * @param money 
     * @param AccountIdFrom 
     * @param AccountIdTo
     */
    public void ProcessTransaction(Integer money, Integer AccountIdFrom, Integer AccountIdTo) {
        // TODO implement here
    }

    /**
     * @param AccountID 
     * @return
     */
    public Integer GetBalance(Integer AccountID) {
        // TODO implement here
        return null;
    }

    /**
     * 
     */
    public void BankServer() {
        // TODO implement here
    }

    /**
     * @param accountId
     */
    public void GetFullAccountInfo(Integer accountId) {
        // TODO implement here
    }

}
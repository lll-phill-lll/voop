
import java.util.*;

/**
 * 
 */
public class Account {

    /**
     * Default constructor
     */
    public Account() {
    }

    /**
     * 
     */
    private Integer AmountOfMoney;

    /**
     * 
     */
    private String Type;

    /**
     * 
     */
    private Integer Id;

    /**
     * 
     */
    private String Login;

    /**
     * 
     */
    private String Password;

    /**
     * 
     */
    public User 1;


    /**
     * @param AmountOfMoney 
     * @param type 
     * @param login 
     * @param password
     */
    public void Account(void AmountOfMoney, String type, String login, String password) {
        // TODO implement here
    }

    /**
     * @return
     */
    public Integer GetAmountOfMoney() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public String GetType() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public INteger GetId() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public String GetLogin() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public String GetPAssword() {
        // TODO implement here
        return "";
    }

}
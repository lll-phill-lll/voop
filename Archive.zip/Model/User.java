
import java.util.*;

/**
 * 
 */
public class User {

    /**
     * Default constructor
     */
    public User() {
    }

    /**
     * 
     */
    private HashSet<Integer> Accounts;

    /**
     * 
     */
    private String Login;

    /**
     * 
     */
    private String Password;

    /**
     * 
     */
    private Bank Bank;


    /**
     * @param login 
     * @param password 
     * @param bank
     */
    public void User(String login, String password, Bank bank) {
        // TODO implement here
    }

}

import java.util.*;

/**
 * 
 */
public class Checker {

    /**
     * Default constructor
     */
    public Checker() {
    }

    /**
     * 
     */
    private BankServer Server;



    /**
     * @param login 
     * @param password 
     * @return
     */
    public boolean CheckPermissions(String login, String password) {
        // TODO implement here
        return false;
    }

    /**
     * @param login 
     * @param password 
     * @param AccountId 
     * @param money 
     * @return
     */
    public boolean CheckMoney(String login, String password, Integer AccountId, Integer money) {
        // TODO implement here
        return false;
    }

    /**
     * @param server
     */
    public void Checker(BankServer server) {
        // TODO implement here
    }

}
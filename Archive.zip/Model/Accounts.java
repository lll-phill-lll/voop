
import java.util.*;

/**
 * 
 */
public class Accounts {

    /**
     * Default constructor
     */
    public Accounts() {
    }

}
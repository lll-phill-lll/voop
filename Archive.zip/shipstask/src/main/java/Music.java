import sun.audio.AudioData;
        import sun.audio.AudioPlayer;
        import sun.audio.AudioStream;
        import sun.audio.ContinuousAudioDataStream;

        import java.io.*;
        import java.util.Objects;

public class Music extends Thread {
    private ContinuousAudioDataStream sound;
    private int duration;
    public Music(String path, int durationSec) {
        this.duration = durationSec * 1000;
        ClassLoader classLoader = ClassLoader.getSystemClassLoader();

        File music = new File(Objects.requireNonNull(classLoader.getResource(path)).getFile());

        AudioData data;
        try {
            data = new AudioStream(new FileInputStream(music)).getData();
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
        this.sound = new ContinuousAudioDataStream(data);


    }
     public void run() {
        if (this.duration == 0) {
            return;
        }
         playMusic();
         try {
             Thread.sleep(this.duration);
         } catch (InterruptedException e) {
             e.printStackTrace();
         }
         stopMusic();
     }

    /**
     * Включает музыку моря
     *
     */
    private void playMusic() {
        AudioPlayer.player.start(this.sound);
    }
    /**
     * Выключает музыку моря
     *
     */
    private void stopMusic() {
        AudioPlayer.player.stop(this.sound);
    }
}

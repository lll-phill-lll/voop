import java.util.Random;

public class ShipGenerator implements Runnable {
    private Tunnel tunnel;
    private int toGenerate;
    private int idCounter = 0;
    private final int COOL_DOWN_MS = 1000;

    public ShipGenerator(Tunnel tunnel, int i) {
        this.tunnel = tunnel;
        this.toGenerate = i;
    }

    @Override
    public void run() {
        while(idCounter < this.toGenerate || this.toGenerate == -1) {
            Ship ship = new Ship(this.getRandomType(), this.getRandomSize(), idCounter);
            ship.start();
            ++idCounter;
            System.out.println("[GENERATOR]: Trying to add to the tunnel ship " + ship);
            this.tunnel.add(ship);
            System.out.println("[GENERATOR]: Successfully added ship to a tunnel " + ship);
            try {
                Thread.sleep(this.COOL_DOWN_MS);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("[GENERATOR]: No more ships to create");
    }

    //вспомогательные методы для генерации кораблей.
    private Ship.Type getRandomType() {
        Random random = new Random();
        return Ship.Type.values()[random.nextInt(Ship.Type.values().length)];
    }

    private Ship.Size getRandomSize() {
        Random random = new Random();
        return Ship.Size.values()[random.nextInt(Ship.Size.values().length)];
    }
}


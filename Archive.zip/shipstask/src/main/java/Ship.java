public class Ship extends Thread {
    private int count;
    private Size size;
    private Type type;
    private State state;
    private int id;
    private final int TIME_TO_LOAD_ONE_BATCH_MS = 1000;
    private final int TIME_TO_WAIT_FOR_NEW_STATE_MS = 1000;
    private final int BATCH_SIZE = 10;
    private final int TIME_TO_GET_GO_PIER_LOADER_MS = 1000;

    public Ship(Type type, Size size, int id) {
        this.id = id;
        this.type = type;
        this.size = size;
        this.state = State.CREATED;
    }

    /**
     * Загружает товары на корабль
     */
    @Override
    public void run() {
        while(true) {
            if (this.state == State.FINISHED_LOADING) {
                return;
            } else {
                try {
                    Thread.sleep(this.TIME_TO_WAIT_FOR_NEW_STATE_MS);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    @Override
    public String toString() {
        return "Ship{" +
                "count=" + this.count +
                ", size=" + this.size +
                ", type=" + this.type +
                ", id=" + this.id +
                ", state=" + this.state +
                '}';
    }

    public enum Type {
        DRESS(1), BANANA(2), MEAL(3);
        private int type;

        Type(int type) {
            this.type = type;
        }
    }

    public enum State {
        CREATED(1), GOING_TO_PIER_LOADER(2), LOADING(3), FINISHED_LOADING(4);
        private int state;

        State(int state) {
            this.state = state;
        }
    }

    public enum Size {
        SMALL(10), MIDDLE(50), LARGE(100);

        Size(int value){
            this.value = value;
        }
        private int value;

        public int getValue() {
            return this.value;
        }
    }

    public Type GetType() {
        return this.type;
    }

    public Size GetSize() {
        return this.size;
    }

    public int GetId() {
        return this.id;
    }

    public boolean countCheck() {
        return this.count < this.size.getValue();
    }

    public void setNewState(State state) {
        if (this.state == State.GOING_TO_PIER_LOADER && state == State.LOADING) {
            try {
                Thread.sleep(this.TIME_TO_GET_GO_PIER_LOADER_MS);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.printf("[SHIP_%d]: Changing state from %s to %s, %s\n", this.id, this.state, state, this);
        this.state = state;
    }
    public void add() {
        this.count += this.BATCH_SIZE;
        try {
            Thread.sleep(this.TIME_TO_LOAD_ONE_BATCH_MS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.printf("[SHIP_%d]: Added %d items %s\n", this.id, this.BATCH_SIZE, this);
    }
}

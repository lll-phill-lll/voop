public class PierLoader extends Thread {
    private Tunnel tunnel;
    private Ship.Type shipType;

    public PierLoader(Tunnel tunnel, Ship.Type shipType) {
        this.tunnel = tunnel;
        this.shipType = shipType;
    }

    @Override
    public void run() {

        while (true) {
            System.out.printf("[PIER_LOADER_%s]: Waiting for the ship\n", this.shipType);
            Ship ship = this.tunnel.get(this.shipType);
            ship.setNewState(Ship.State.LOADING);
            //берет из тоннеля корабль соответствующего типа
            System.out.printf("[PIER_LOADER_%s]: Started loading ship %s\n", this.shipType, ship);
            while (ship.countCheck()) {
                ship.add();
                //загружает на него товар, пока корабль не наполнится
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            ship.setNewState(Ship.State.FINISHED_LOADING);
            System.out.printf("[PIER_LOADER_%s]: Finished loading ship %s\n", this.shipType, ship);
        }
    }
}


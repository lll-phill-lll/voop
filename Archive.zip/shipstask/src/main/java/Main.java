import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {

    public static void main(String[] args) {
        System.out.println("Available number of cores: " + Runtime.getRuntime().availableProcessors());
        ExecutorService service = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

        Tunnel tunnel = new TunnelImpl();

        ShipGenerator shipGenerator = new ShipGenerator(tunnel, 5);

        PierLoader pierLoader1 = new PierLoader(tunnel, Ship.Type.DRESS);
        PierLoader pierLoader2 = new PierLoader(tunnel, Ship.Type.BANANA);
        PierLoader pierLoader3 = new PierLoader(tunnel, Ship.Type.MEAL);

        Music music = new Music("music/beach.wav", 0);

        music.start();

        pierLoader1.setDaemon(true);
        pierLoader2.setDaemon(true);
        pierLoader3.setDaemon(true);

        pierLoader1.start();
        pierLoader2.start();
        pierLoader3.start();

        service.execute(shipGenerator);


        service.shutdown();
    }

}

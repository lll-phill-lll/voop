import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class TunnelImplTest {
    private Tunnel tunnel;
    @Before
    public void init() {
        this.tunnel = new TunnelImpl();
    }

    @Test
    public void addFiveShipsWithoutWait() {
        for (int i = 0; i != 5; ++i) {
            Ship ship = new Ship(Ship.Type.BANANA, Ship.Size.MIDDLE, 5);
            boolean added = tunnel.add(ship);
            assertTrue(added);
        }
    }

    @Test
    public void getAllShips() {
        // when tunnel has 3 ships inside
        Ship.Type[] types = {Ship.Type.BANANA, Ship.Type.DRESS, Ship.Type.MEAL};
        Ship.Size[] sizes = {Ship.Size.LARGE, Ship.Size.MIDDLE, Ship.Size.SMALL};
        for (int i = 0; i != 3; ++i) {
            Ship.Type type = types[i];
            Ship.Size size = sizes[i];
            Ship ship = new Ship(type, size, i);
            tunnel.add(ship);
        }

        // then it has to return all of them
        for (int i = 0; i != 3; ++i) {
            Ship ship = tunnel.get(types[i]);
            assertNotNull(ship);
            assertEquals(ship.GetType(), types[i]);
            assertEquals(ship.GetSize(), sizes[i]);
            assertEquals(ship.GetId(), i);
        }

    }
}
import org.junit.Test;

import static org.junit.Assert.*;

public class ShipTest {

    @Test
    public void getType() {
        Ship.Type[] types = {Ship.Type.BANANA, Ship.Type.DRESS, Ship.Type.MEAL};
        for (Ship.Type type : types) {
            Ship ship = new Ship(type, Ship.Size.LARGE, 5);
            assertEquals(type, ship.GetType());
        }
    }

    @Test
    public void countCheck() {
        Ship.Size[] sizes = {Ship.Size.LARGE, Ship.Size.MIDDLE, Ship.Size.SMALL};
        for (Ship.Size size : sizes) {
            Ship ship = new Ship(Ship.Type.BANANA, size, 5);
            int s = size.getValue();
            while (s > 0) {
                assertTrue(ship.countCheck());
                ship.add();
                s -= 10;
            }
            assertFalse(ship.countCheck());
        }
    }
}